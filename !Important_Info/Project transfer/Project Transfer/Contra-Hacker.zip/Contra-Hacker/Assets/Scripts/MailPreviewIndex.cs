using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MailPreviewIndex : MonoBehaviour
{
    public int givenIndex = 0;
    public TextMeshProUGUI senderText;
    public TextMeshProUGUI subjectText;
    public Button button;
    // Start is called before the first frame update
    
    // Update is called once per frame

}
